# ATY AI STUDIO — starter project

Starter ini menyediakan:
- Flutter Android UI awal.
- FastAPI backend.
- Endpoint text-to-image melalui Hugging Face Inference Providers.
- Endpoint text-to-video melalui Hugging Face `InferenceClient`.
- Endpoint text-to-speech dengan `edge-tts`.
- Contoh konfigurasi Firebase dependencies.

## Penting: status starter
Ini adalah kerangka awal yang bisa dikembangkan, bukan APK final dan belum merupakan aplikasi produksi.
Google login, upload foto untuk image-to-video, galeri cloud, billing/quota, dan penyimpanan per pengguna masih harus dikonfigurasi dan diuji.
Tidak ada token rahasia yang ditanam di APK.

## A. Bangun backend
1. Buat server Python yang dapat diakses melalui HTTPS.
2. Salin folder `backend`.
3. Install dependensi:
   `pip install -r requirements.txt`
4. Salin `.env.example` menjadi `.env`, isi `HF_TOKEN`.
5. Jalankan:
   `uvicorn main:app --host 0.0.0.0 --port 8000`
6. Uji `https://DOMAIN-KAMU/health`.

Token Hugging Face dibuat di Settings > Access Tokens. Batasi izin token sesuai kebutuhan dan jangan bagikan token.
Inference Providers memiliki kredit gratis yang kecil dan dapat berubah; penggunaan di luar kredit dapat dikenakan biaya. Periksa harga provider sebelum menjalankan generasi.

## B. Siapkan Firebase
1. Buka https://console.firebase.google.com/ dan buat project.
2. Tambahkan aplikasi Android dengan application ID `com.aty.ai_studio` (samakan saat membuat proyek Flutter).
3. Aktifkan Authentication: Email/Password dan Google.
4. Aktifkan Cloud Firestore dan Storage jika dibutuhkan.
5. Di lingkungan build yang memiliki Flutter SDK, jalankan:
   `dart pub global activate flutterfire_cli`
   `flutterfire configure`
6. Tambahkan inisialisasi Firebase dari `firebase_options.dart` ke `main.dart`.
7. Implementasikan alur sign-in Google dan email sebelum rilis. Jangan menganggap tombol profil pada starter ini sebagai login yang sudah aktif.

Dokumentasi: https://firebase.google.com/docs/flutter/setup
https://firebase.google.com/docs/auth/flutter/start

## C. Build APK
Pada komputer cloud/CI yang memiliki Flutter dan Android SDK:
1. `flutter pub get`
2. `flutter build apk --release --dart-define=ATY_API_URL=https://DOMAIN-KAMU`
3. APK berada di `build/app/outputs/flutter-apk/app-release.apk`.

Build dari HP Android dapat dilakukan melalui layanan cloud IDE atau GitHub Actions; tidak perlu Android Studio terpasang di HP.
Jangan publikasikan APK sebelum menguji autentikasi, izin, privasi, dan biaya API.

## D. Keterbatasan yang harus diselesaikan
- Video provider/model yang tersedia dapat berubah; pastikan provider mendukung model dan akun memiliki kredit.
- Text-to-video di server bergantung pada respons provider dan bisa memerlukan penyesuaian versi `huggingface_hub`.
- Image-to-video belum diaktifkan pada starter ini.
- TTS memakai layanan edge-tts; periksa ketentuan penggunaan layanan sebelum aplikasi publik.
- Output disimpan lokal di server contoh ini. Untuk produksi gunakan object storage, autentikasi backend, URL bertanda tangan, batas ukuran, dan penghapusan otomatis.
- Tambahkan antrean job untuk generasi video yang lama; request HTTP sinkron pada starter ini hanya untuk uji awal.
